-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 27/10/2025 às 14:46
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `aplicativos`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `aplicativos`
--

CREATE TABLE `aplicativos` (
  `id_aplicativos` int(11) NOT NULL,
  `nome` varchar(100) DEFAULT NULL,
  `categoria` varchar(50) DEFAULT NULL,
  `dowloads_milhoes` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `aplicativos`
--

INSERT INTO `aplicativos` (`id_aplicativos`, `nome`, `categoria`, `dowloads_milhoes`) VALUES
(1, 'Instagram', 'Rede Social', 4000),
(2, 'Whastapp', 'Comunicação', 5000),
(3, 'Tik Tok', 'Rede Social', 4500);

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `aplicativos`
--
ALTER TABLE `aplicativos`
  ADD PRIMARY KEY (`id_aplicativos`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `aplicativos`
--
ALTER TABLE `aplicativos`
  MODIFY `id_aplicativos` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
